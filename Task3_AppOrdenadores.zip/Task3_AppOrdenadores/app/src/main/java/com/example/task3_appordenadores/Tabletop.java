package com.example.task3_appordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tabletop extends AppCompatActivity {
    protected final static String TABLETOP_CODE_PRODUCT1 = "com.example.task3_appordenadores.productCodeTabletop1";
    protected final static String TABLETOP_CODE_PRODUCT2 = "com.example.task3_appordenadores.productCodeTabletop2";

    Button btnTabletop1, btnTabletop2;
    String category, codeCategory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabletop);

        initialize();
    }

    public void initialize(){
        Intent intent = getIntent();
        category = intent.getStringExtra(Home.TABLETOP_CATEGORY);
        codeCategory = intent.getStringExtra(Home.TABLETOP_CODE);


        btnTabletop1 = (Button) findViewById(R.id.btn_TableCat_Detail1);
        btnTabletop2 = (Button) findViewById(R.id.btn_TableCat_Detail2);

    }

    public void chooseTabletop1(View v) {
        String tabletopProductCode1 = "20000-1";
        Intent intentDetails = new Intent(this, TableTopDetails.class);
        intentDetails.putExtra(TABLETOP_CODE_PRODUCT1, tabletopProductCode1);
        intentDetails.putExtra(Home.TABLETOP_CATEGORY, category);
        intentDetails.putExtra(Home.TABLETOP_CODE, codeCategory);
        startActivity(intentDetails);
    }

    public  void chooseTabletop2(View v){
        String tabletopProductCode2 = "20000-2";
        Intent intentDetails = new Intent(this, TableTopDetails.class);
        intentDetails.putExtra(TABLETOP_CODE_PRODUCT2, tabletopProductCode2);
        intentDetails.putExtra(Home.TABLETOP_CATEGORY, category);
        intentDetails.putExtra(Home.TABLETOP_CODE, codeCategory);
        startActivity(intentDetails);
    }

    public void goHome(View v){
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }
}