package com.example.task3_appordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CatalogueLaptop extends AppCompatActivity {
    protected final static String LAPTOP_CODE_PRODUCT1 = "com.example.task3_appordenadores.productCodeLaptop1";
    protected final static String LAPTOP_CODE_PRODUCT2 = "com.example.task3_appordenadores.productCodeLaptop2";

    Button btnLaptop1, btnLaptop2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogue_laptop);

        initialize();
    }

    public void initialize() {


        btnLaptop1 = (Button) findViewById(R.id.btn_details_laptop1);
        btnLaptop2 = (Button) findViewById(R.id.btn_details_laptop2);
    }

    public void chooseLaptop1(View v) {

        Intent intentDetails = new Intent(this, LapTopDetails.class);
        String laptopProductCode1 = "10000-1";

        intentDetails.putExtra(LAPTOP_CODE_PRODUCT1, laptopProductCode1);
        startActivity(intentDetails);

    }

    public void chooseLaptop2(View v) {

        Intent intentDetailsII = new Intent(this, LapTopDetails.class);
        String laptopProductCode2 = "10000-2";

        intentDetailsII.putExtra(LAPTOP_CODE_PRODUCT2, laptopProductCode2);
        startActivity(intentDetailsII);

    }
}