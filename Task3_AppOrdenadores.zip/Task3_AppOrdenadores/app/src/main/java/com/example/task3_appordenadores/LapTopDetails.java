package com.example.task3_appordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class LapTopDetails extends AppCompatActivity {

    TextView price, modelName, codeProduct, codeCategory, stock, nameLap, category;
    ImageView asus, acer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lap_top_details);

        initialize();
    }

    public void initialize() {
        nameLap = (TextView) findViewById(R.id.tv_nameLap);
        category = (TextView) findViewById(R.id.tv_getCategory);
        price = (TextView) findViewById(R.id.tv_getPriceLaptop);
        codeCategory = (TextView) findViewById(R.id.tv_getcodeCateg);
        codeProduct = (TextView) findViewById(R.id.tv_getCodeProduc);
        stock = (TextView) findViewById(R.id.tv_getStockNum);
        modelName = (TextView) findViewById(R.id.tv_getModeloLaptop);
        asus = (ImageView) findViewById(R.id.img_table_detail1);
        acer = (ImageView) findViewById(R.id.img_table_detail2);

        asus.setVisibility(View.GONE);
        acer.setVisibility(View.GONE);

        showDetails();
        showDetailsII();
    }

    public void showDetails() {

        Intent intent = getIntent();
        String laptopCateg = intent.getStringExtra(Home.LAPTOP_CATEGORY);
        String latopCode = intent.getStringExtra(Home.LAPTOP_CODE);
        String laptopAsusCode = intent.getStringExtra(Laptop.LAPTOP_CODE_PRODUCT1);

        if (laptopAsusCode != null) {
            if (laptopAsusCode.equals("10000-1")) {
                asus.setVisibility(View.VISIBLE);
                category.setText(laptopCateg);
                nameLap.setText("Asus TUF Gaming F15 ");
                modelName.setText("FX506HCB-HN200");
                price.setText("12000,00€");
                codeCategory.setText(latopCode);
                codeProduct.setText(laptopAsusCode);
                stock.setText("3");

            } else {
                Toast.makeText(this, "ERROR1-2", Toast.LENGTH_LONG);
            }
        } else {
            Toast.makeText(this, "ERROR1-1", Toast.LENGTH_LONG);
        }

    }

    public void showDetailsII() {

        Intent intent = getIntent();
        String laptopCateg = intent.getStringExtra(Home.LAPTOP_CATEGORY);
        String latopCode = intent.getStringExtra(Home.LAPTOP_CODE);
        String laptopAcerCode = intent.getStringExtra(Laptop.LAPTOP_CODE_PRODUCT2);

        if (laptopAcerCode != null) {
            if (laptopAcerCode.equals("10000-2")) {
                acer.setVisibility(View.VISIBLE);
                nameLap.setText("Acer Nitro 5");
                modelName.setText("AN515-55-72GW");
                category.setText(laptopCateg);
                price.setText("2000€");
                codeCategory.setText(latopCode);
                codeProduct.setText(laptopAcerCode);
                stock.setText("2");
            } else {
                Toast.makeText(this, "ERROR2-2", Toast.LENGTH_LONG);
            }
        } else {
            Toast.makeText(this, "ERROR2-1", Toast.LENGTH_LONG);
        }
    }

    public void goHome(View v){
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }
    public void goLaptop(View v){
        Intent intent = new Intent(this, Laptop.class);
        startActivity(intent);
    }
}