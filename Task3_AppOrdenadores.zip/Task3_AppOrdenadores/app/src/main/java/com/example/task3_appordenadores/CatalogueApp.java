package com.example.task3_appordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class CatalogueApp extends AppCompatActivity {
    protected static final String TABLETOP_CODE = "com.example.task3_appordenadores.tabletopCode";
    protected static final String LAPTOP_CODE = "com.example.task3_appordenadores.laptopCode";
    protected static final String LAPTOP_CATEGORY = "com.example.task3_appordenadores.portatiles";
    protected static final String TABLETOP_CATEGORY = "com.example.task3_appordenadores.sobremesa";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogue_app);

    }

    public void selectLaptop(View v) {
        String laptopCode = "10000";
        String laptopCateg = "Portatiles";

        Intent intentLap = new Intent(this, CatalogueTableTop.class);
        intentLap.putExtra(LAPTOP_CODE, laptopCode);
        intentLap.putExtra(LAPTOP_CATEGORY, laptopCateg);
        startActivity(intentLap);
    }

    public void selectTabletop(View v) {
        String tabletopCode = "20000";
        String tabletopCateg = "Sobremesa";

        Intent intentTable = new Intent(this, CatalogueTableTop.class);
        startActivity(intentTable);

//        Intent intentTable = new Intent(this, CatalogueTableTop.class);
//        intentTable.putExtra(TABLETOP_CODE, tabletopCode);
//        intentTable.putExtra(TABLETOP_CATEGORY, tabletopCateg);
//        startActivity(intentTable);
    }

    public void testBtn (View v){
        Intent intentTest = new Intent(this, TestActivity.class);
        startActivity(intentTest);
    }
}