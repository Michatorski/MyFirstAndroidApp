package com.example.task3_appordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class CatalogueApp extends AppCompatActivity {
    private static final String TABLETOP_CODE = "com.example.task3_appordenadores.tabletopCode";
    private static final String LAPTOP_CODE = "com.example.task3_appordenadores.laptopCode";
    private static final String LAPTOP_CATEGORY = "com.example.task3_appordenadores.portatiles";
    private static final String TABLETOP_CATEGORY = "com.example.task3_appordenadores.sobremesa";

    ImageButton imb_tabletop, imb_laptop;
    Button b_Tabletop, b_Laptop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogue_app);
        initialize();
    }

    public void initialize(){
        imb_tabletop = (ImageButton) findViewById(R.id.imb_catApp_tabletop);
        imb_laptop = (ImageButton) findViewById(R.id.imb_catApp_laptop);

        b_Tabletop = (Button) findViewById(R.id.btn_catApp_tabletop);
        b_Laptop = (Button) findViewById(R.id.btn_catApp_laptop);
    }

    public void selectPc(View v){



        String laptopCode = "10000";
        String tabletopCode = "20000";

        String laptopCateg = "Portatiles";
        String tabletopCateg = "Sobremesa";

        if (imb_laptop.callOnClick() || b_Laptop.callOnClick()){
            Intent intentLap = new Intent(this, CatalogueLaptop.class);
            intentLap.putExtra(LAPTOP_CODE, laptopCode);
            intentLap.putExtra(LAPTOP_CATEGORY, laptopCateg);
            startActivity(intentLap);
        }
        if (imb_tabletop.callOnClick() || b_Tabletop.callOnClick()){
            Intent intentTable = new Intent(this, CatalogueTableTop.class);
            intentTable.putExtra(TABLETOP_CODE, tabletopCode);
            intentTable.putExtra(TABLETOP_CATEGORY, tabletopCateg);
            startActivity(intentTable);
        }
    }
}