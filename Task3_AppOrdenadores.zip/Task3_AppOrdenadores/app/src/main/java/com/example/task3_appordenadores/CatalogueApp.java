package com.example.task3_appordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CatalogueApp extends AppCompatActivity {
    private static final String TABLETOP_CATEGORY = "20000";
    private static final String LAPTOP_CATEGORY = "10000";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogue_app);
    }

    public void Initialize(){

    }
}