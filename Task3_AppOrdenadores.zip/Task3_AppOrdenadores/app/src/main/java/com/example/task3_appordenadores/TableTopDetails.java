package com.example.task3_appordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class TableTopDetails extends AppCompatActivity {

    TextView price, modelName, codeProduct, codeCategory, stock, nameTable, category;
    ImageView gold, silver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_top_details);

        initialize();
    }

    public void initialize() {
        nameTable = (TextView) findViewById(R.id.tv_nameTable);
        category = (TextView) findViewById(R.id.tv_getCategoryTable);
        price = (TextView) findViewById(R.id.tv_getPriceTable);
        codeCategory = (TextView) findViewById(R.id.tv_getcodeCategTable);
        codeProduct = (TextView) findViewById(R.id.tv_getCodeProductTable);
        stock = (TextView) findViewById(R.id.tv_getStockNumTable);
        modelName = (TextView) findViewById(R.id.tv_getModeloTabletop);
        gold = (ImageView) findViewById(R.id.img_pcGold);
        silver = (ImageView) findViewById(R.id.img_pcSilver);

        gold.setVisibility(View.GONE);
        silver.setVisibility(View.GONE);

        showDetails();
        showDetailsII();
    }

    public void showDetails() {

        Intent intent = getIntent();
        String tableCateg = intent.getStringExtra(Home.TABLETOP_CATEGORY);
        String tableCode = intent.getStringExtra(Home.TABLETOP_CODE);
        String tableTopGoldCode = intent.getStringExtra(Tabletop.TABLETOP_CODE_PRODUCT1);

        if (tableTopGoldCode != null) {
            if (tableTopGoldCode.equals("20000-1")) {
                gold.setVisibility(View.VISIBLE);
                category.setText(tableCateg);
                nameTable.setText("PCCOM Gold");
                modelName.setText("FX506HCB-HN200");
                price.setText("12000,00€");
                codeCategory.setText(tableCode);
                codeProduct.setText(tableTopGoldCode);
                stock.setText("3");

            } else {
                Toast.makeText(this, "ERROR1-2", Toast.LENGTH_LONG);
            }
        } else {
            Toast.makeText(this, "ERROR1-1", Toast.LENGTH_LONG);
        }

    }

    public void showDetailsII() {

        Intent intent = getIntent();
        String tableCateg = intent.getStringExtra(Home.TABLETOP_CATEGORY);
        String tableCode = intent.getStringExtra(Home.TABLETOP_CODE);
        String tableTopSilverCode = intent.getStringExtra(Tabletop.TABLETOP_CODE_PRODUCT2);

        if (tableTopSilverCode != null) {
            if (tableTopSilverCode.equals("20000-2")) {
                silver.setVisibility(View.VISIBLE);
                nameTable.setText("PCCOM Silver");
                modelName.setText("AN515-55-72GW");
                category.setText(tableCateg);
                price.setText("2600€");
                codeCategory.setText(tableCode);
                codeProduct.setText(tableTopSilverCode);
                stock.setText("7");
            } else {
                Toast.makeText(this, "ERROR2-2", Toast.LENGTH_LONG);
            }
        } else {
            Toast.makeText(this, "ERROR2-1", Toast.LENGTH_LONG);
        }
    }

    public void goHome(View v){
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }
    public void goTabletop(View v){
        Intent intent = new Intent(this, Tabletop.class);
        startActivity(intent);
    }
}